package com.minemart.itemcoreforge.utils;

import com.minemart.itemcoreforge.core.Forge;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

public class ItemReference {

    private String source = "itemcore";
    private String category = "";
    private String id = "";
    private int amount = 1;
    private boolean checkDurability = false;

    public ItemReference() {
    }

    public static ItemReference fromString(String str) {
        ItemReference ref = new ItemReference();
        
        if (str == null || str.isEmpty()) {
            return ref;
        }
        
        if (str.startsWith("itemcore:")) {
            ref.setSource("itemcore");
            String remaining = str.substring(9);
            parseItemCoreFormat(ref, remaining);
        } else if (str.startsWith("vanilla:")) {
            ref.setSource("vanilla");
            String remaining = str.substring(8);
            parseVanillaFormat(ref, remaining);
        } else {
            ref.setSource("itemcore");
            ref.setId(str);
        }
        
        return ref;
    }

    private static void parseItemCoreFormat(ItemReference ref, String str) {
        String[] parts = str.split("/");
        if (parts.length == 2) {
            ref.setCategory(parts[0]);
            String idAndAmount = parts[1];
            parseIdAndAmount(ref, idAndAmount);
        } else {
            parseIdAndAmount(ref, str);
        }
    }

    private static void parseVanillaFormat(ItemReference ref, String str) {
        parseIdAndAmount(ref, str);
    }

    private static void parseIdAndAmount(ItemReference ref, String str) {
        if (str.contains("*")) {
            String[] parts = str.split("\\*");
            ref.setId(parts[0]);
            if (parts.length > 1) {
                try {
                    ref.setAmount(Integer.parseInt(parts[1]));
                } catch (NumberFormatException e) {
                    ref.setAmount(1);
                }
            }
        } else {
            ref.setId(str);
        }
    }

    public ItemStack toItemStack() {
        if (isItemCore()) {
            return resolveItemCoreItem();
        } else {
            return resolveVanillaItem();
        }
    }

    private ItemStack resolveItemCoreItem() {
        try {
            Class<?> apiClass = Class.forName("com.minemart.itemcore.api.ItemCoreAPI");
            Object api = apiClass.getMethod("getInstance").invoke(null);
            Object itemStack = apiClass.getMethod("getItemStack", String.class, int.class)
                .invoke(api, id, amount);
            return (ItemStack) itemStack;
        } catch (Exception e) {
            return new ItemStack(Material.AIR);
        }
    }

    private ItemStack resolveVanillaItem() {
        try {
            Material material = Material.valueOf(id.toUpperCase());
            return new ItemStack(material, amount);
        } catch (IllegalArgumentException e) {
            return new ItemStack(Material.AIR);
        }
    }

    public boolean isValid() {
        return id != null && !id.isEmpty() && amount > 0;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public boolean isItemCore() {
        return "itemcore".equalsIgnoreCase(source);
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = Math.max(1, amount);
    }

    public boolean isCheckDurability() {
        return checkDurability;
    }

    public void setCheckDurability(boolean checkDurability) {
        this.checkDurability = checkDurability;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(source).append(":");
        if (isItemCore() && !category.isEmpty()) {
            sb.append(category).append("/");
        }
        sb.append(id);
        if (amount > 1) {
            sb.append("*").append(amount);
        }
        return sb.toString();
    }
}
