package com.minemart.itemcoreforge;

import com.minemart.itemcoreforge.config.ConfigManager;
import com.minemart.itemcoreforge.config.ForgeLoader;
import com.minemart.itemcoreforge.config.LayoutLoader;
import com.minemart.itemcoreforge.core.ForgeManager;
import com.minemart.itemcoreforge.gui.GuiListener;
import com.minemart.itemcoreforge.storage.DataStorage;
import com.minemart.itemcoreforge.task.CraftingQueueManager;
import com.minemart.itemcoreforge.type.ForgeTypeManager;
import com.minemart.itemcoreforge.utils.MaterialChecker;
import com.minemart.itemcoreforge.utils.MessageUtil;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

public class ItemCoreForge extends JavaPlugin implements Listener {

    private static ItemCoreForge instance;
    
    private ConfigManager configManager;
    private ForgeLoader forgeLoader;
    private LayoutLoader layoutLoader;
    private ForgeManager forgeManager;
    private CraftingQueueManager craftingQueueManager;
    private GuiListener guiListener;
    private DataStorage dataStorage;
    private ForgeTypeManager typeManager;
    private MaterialChecker materialChecker;

    @Override
    public void onEnable() {
        instance = this;
        
        if (!checkItemCore()) {
            getLogger().warning("未检测到 ItemCore 插件，将仅支持 vanilla 物品！");
        }
        
        initManagers();
        loadConfigs();
        registerCommands();
        registerListeners();
        registerTypeHandlers();
        
        getLogger().info("ItemCoreForge 已启用！版本: " + getDescription().getVersion());
    }

    @Override
    public void onDisable() {
        if (dataStorage != null) {
            dataStorage.saveAllData();
        }
        if (craftingQueueManager != null) {
            craftingQueueManager.shutdown();
        }
        if (typeManager != null) {
            typeManager.disableAll();
        }
        
        getLogger().info("ItemCoreForge 已禁用！");
    }

    private boolean checkItemCore() {
        return getServer().getPluginManager().getPlugin("ItemCore") != null;
    }

    private void initManagers() {
        configManager = new ConfigManager(this);
        forgeLoader = new ForgeLoader(this);
        layoutLoader = new LayoutLoader(this);
        forgeManager = new ForgeManager(this);
        materialChecker = new MaterialChecker();
        craftingQueueManager = new CraftingQueueManager(this);
        dataStorage = new DataStorage(this);
        typeManager = new ForgeTypeManager(this);
    }

    private void registerTypeHandlers() {
        typeManager.init();
        typeManager.enableAll();
        for (com.minemart.itemcoreforge.core.Forge forge : forgeLoader.getAllForges()) {
            typeManager.registerForgeToHandler(forge);
        }
    }

    private void loadConfigs() {
        configManager.load();
        forgeLoader.loadAll();
        layoutLoader.loadAll();
        getLogger().info("已加载 " + forgeLoader.getForgeCount() + " 个锻造台");
    }

    private void registerCommands() {
        getCommand("itemcoreforge").setExecutor(new com.minemart.itemcoreforge.command.ForgeCommand(this));
        getCommand("itemcoreforge").setTabCompleter(new com.minemart.itemcoreforge.command.ForgeTabCompleter(this));
    }

    private void registerListeners() {
        guiListener = new GuiListener(this);
        getServer().getPluginManager().registerEvents(guiListener, this);
        getServer().getPluginManager().registerEvents(this, this);
    }
    
    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        if (dataStorage != null) {
            dataStorage.loadPlayerData(event.getPlayer());
        }
    }
    
    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        if (dataStorage != null) {
            dataStorage.savePlayerData(event.getPlayer());
        }
    }

    public void reload() {
        configManager.reload();
        forgeLoader.loadAll();
        layoutLoader.loadAll();
        getLogger().info("配置已重载！已加载 " + forgeLoader.getForgeCount() + " 个锻造台");
        
        if (typeManager != null) {
            typeManager.reloadAll();
            for (com.minemart.itemcoreforge.core.Forge forge : forgeLoader.getAllForges()) {
                typeManager.registerForgeToHandler(forge);
            }
        }
    }

    public static ItemCoreForge getInstance() {
        return instance;
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }

    public ForgeLoader getForgeLoader() {
        return forgeLoader;
    }

    public LayoutLoader getLayoutLoader() {
        return layoutLoader;
    }

    public ForgeManager getForgeManager() {
        return forgeManager;
    }

    public CraftingQueueManager getCraftingQueueManager() {
        return craftingQueueManager;
    }

    public GuiListener getGuiListener() {
        return guiListener;
    }
    
    public DataStorage getDataStorage() {
        return dataStorage;
    }
    
    public ForgeTypeManager getTypeManager() {
        return typeManager;
    }
    
    public MaterialChecker getMaterialChecker() {
        return materialChecker;
    }
}
