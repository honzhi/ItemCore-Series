# ItemCoreLevel
等级系统

ItemCore:https://www.spigotmc.org/resources/itemcore.135848/

###  指令

主指令: `/itemcorelevel`（别名: `/icl`）

| 子指令 | 权限 | 默认 | 说明 |
|--------|------|------|------|
| `icl help` | `itemcorelevel.command.help` | true | 显示插件帮助 |
| `icl info [player]` | `itemcorelevel.command.info` | true | 查看等级信息 |
| `icl add <player> <amount>` | `itemcorelevel.command.add` | op | 增加经验 |
| `icl remove <player> <amount>` | `itemcorelevel.command.remove` | op | 扣除经验 |
| `icl set <player> <level>` | `itemcorelevel.command.set` | op | 设置等级 |
| `icl setexp <player> <amount>` | `itemcorelevel.command.setexp` | op | 设置经验值 |
| `icl reset <player>` | `itemcorelevel.command.reset` | op | 重置玩家数据 |
| `icl reload` | `itemcorelevel.command.reload` | op | 重载配置 |

### 权限节点

| 权限 | 默认 | 说明 |
|------|------|------|
| `itemcorelevel.admin` | op | 管理员总权限（包含以下所有 op 权限的子权限） |
| `itemcorelevel.command.help` | true | 查看帮助 |
| `itemcorelevel.command.info` | true | 查看自己的等级信息 |
| `itemcorelevel.command.info.other` | op | 查看他人的等级信息 |
| `itemcorelevel.command.add` | op | 增加经验 |
| `itemcorelevel.command.remove` | op | 扣除经验 |
| `itemcorelevel.command.set` | op | 设置等级 |
| `itemcorelevel.command.setexp` | op | 设置经验值 |
| `itemcorelevel.command.reset` | op | 重置玩家 |
| `itemcorelevel.command.reload` | op | 重载配置 |

---

## PlaceholderAPI 变量

| 变量 | 类型 | 说明 |
|------|------|------|
| `%itemcorelevel_level%` | int | 玩家当前等级 |
| `%itemcorelevel_exp%` | int | 玩家当前经验值 |
| `%itemcorelevel_exp_required%` | int | 升到下一级所需总经验 |
| `%itemcorelevel_exp_progress%` | double | 本级经验百分比 0.0~1.0 |
| `%itemcorelevel_exp_progress_bar%` | String | 渲染后的进度条（█░） |
| `%itemcorelevel_exp_remaining%` | int | 距升级还差多少经验 |
| `%itemcorelevel_max_level%` | int | 服务器最大等级 |


所有配置项集中在 `config.yml` 中，随插件默认打包，首次运行自动生成。每段配置都有详细注释说明。

```yaml
# ========================================
# ItemCoreLevel 配置文件
# 基于 ItemCore 的玩家等级系统扩展插件
# ========================================

# ─────────────────────────────────────
# 调试模式
# ─────────────────────────────────────
# 启用后输出更详细的日志信息，用于问题排查
# 生产环境建议关闭
debug: false

# ─────────────────────────────────────
# 基础等级设置
# ─────────────────────────────────────

# 新玩家进入服务器时的初始等级
start-level: 1

# 新玩家进入服务器时的初始经验值
start-exp: 0

# 玩家可达到的最高等级
# 设为 0 表示无限制
max-level: 100

# ─────────────────────────────────────
# 等级经验曲线
# ─────────────────────────────────────
# 控制每升一级需要多少经验值
#
# mode: 经验计算模式
#   formula - 公式模式，使用 expression 字段的公式计算
#   list    - 列表模式，使用 list 字段手动指定每级所需经验
#
# expression: 公式表达式（仅 formula 模式有效）
#   可用变量: {level} = 当前等级
#   支持运算符: + - * / ^ ( )
#   示例:
#     100*{level}             → 线性增长，1级需100，2级需200
#     100*{level}^2           → 平方增长，1级需100，2级需400
#     100*{level}^2+50*{level} → 混合增长，1级需150，2级需500
#
# list: 经验列表（仅 list 模式有效）
#   第 0 项 = 1级升2级所需经验
#   第 1 项 = 2级升3级所需经验，以此类推
level-curve:
  mode: formula
  expression: "100*{level}^2+50*{level}"
  # list:
  #   - 100
  #   - 200
  #   - 400
  #   - 800

# ─────────────────────────────────────
# 等级属性奖励
# ─────────────────────────────────────
# 玩家升级后可获得的 ItemCore 属性加成
# 这些属性会通过 AttributeProvider 注册到 ItemCore 的属性计算系统
# general: 通用奖励（每级累加）
#   属性值 = 配置值 × 当前等级
#   例如 attack_damage: 0.5，玩家 10 级时获得 5 点攻击伤害
#
# specific: 特定等级奖励（达到指定等级时一次性给予）
#   键 = 等级，值 = 该等级解锁的属性
#   例如 10 级时额外获得 5 攻击伤害 + 2% 暴击率
#   注意：specific 奖励不会重复叠加，到达该等级后永久生效
level-rewards:
  general:
    # 每级增加 0.5 攻击伤害
    attack_damage: 0.5
    # 每级增加 1 点生命值
    health: 1.0
  specific:
    10:
      attack_damage: 5.0
      crit_chance: 2.0
      health: 10.0
    20:
      attack_damage: 10.0
      crit_damage: 5.0
      spell_power: 5.0
    30:
      armor: 5.0
      physical_resist: 3.0
      spell_resist: 3.0
    50:
      adaptive_force: 5.0
      damage_reduction: 2.0

# ─────────────────────────────────────
# MythicMobs 经验掉落配置
# ─────────────────────────────────────
# 配置 MythicMobs 怪物死亡时玩家获得的经验值
# 注意：此区域仅在安装了 MythicMobs 插件时生效
monster-exp:
  # 未在下方 mobs 列表中明确配置的怪物，默认给予的经验值
  default: 10

  # 是否根据 MythicMobs 的怪物等级字段自动计算经验值
  # 启用后，若怪物在 MM 配置中设置了 Level 字段
  # 则使用 mob-level-formula 计算经验值，替代 default 值
  use-mob-level: true

  # 基于怪物等级的计算公式（仅 use-mob-level 为 true 时有效）
  # {level} = 怪物在 MythicMobs 中配置的等级
  mob-level-formula: "{level}*5+10"

  # 特定怪物的经验值映射
  # key   = MythicMobs 怪物配置中的内部 ID
  # value = 击杀该怪物获得的经验值
  # 优先级: 此处明确配置 > mob-level-formula 计算 > default
  mobs:
    SkeletonKing: 100
    ZombieLord: 75
    Goblin: 15
    GoblinWarrior: 25
    Dragon: 500

# ─────────────────────────────────────
# 经验获取来源设置
# ─────────────────────────────────────
exp-sources:
  # MythicMobs 怪物击杀经验
  mythicmobs:
    # 是否启用怪物击杀获得经验
    enabled: true
    # 是否仅最后一击的玩家获得经验
    # false 时，以怪物为中心半径 30 格内的所有玩家平分经验
    killer-only: true
    # 是否与队伍成员分享经验（需队伍插件支持，预留）
    share-in-party: false
    # 经验值倍率
    # 所有来源的经验值乘以该倍率，1.0 = 100%
    # 可用于特殊活动时临时调整
    multiplier: 1.0

# ─────────────────────────────────────
# 经验获取提示
# ─────────────────────────────────────
# 玩家获得经验时聊天栏显示的文字
# 支持以下占位符:
#   {player}   - 玩家名
#   {amount}   - 获得的经验值数量
#   {level}    - 当前等级
#   {exp}      - 当前经验值
#   {required} - 升级所需总经验
#   {progress} - 百分比进度（保留1位小数）
# 支持 Minecraft 颜色代码 (&0-&f, &l, &m, &n, &o, &r)
exp-gain:
  # 获得经验时是否在聊天栏显示提示
  enabled: true
  # 提示文字格式
  # 设为空字符串 "" 则不显示
  message: "&a+{amount} &7经验值 (&f{progress}&7)"
  # 获取经验时发送的声音（留空表示不播放）
  # 可用值参考: https://hub.spigotmc.org/javadocs/spigot/org/bukkit/Sound.html
  sound: "ENTITY_EXPERIENCE_ORB_PICKUP"
  # 声音音量 (0.0 ~ 1.0)
  sound-volume: 0.5
  # 声音音调 (0.5 ~ 2.0)
  sound-pitch: 1.0

# ─────────────────────────────────────
# 升级提示配置
# enabled: false 时完全不发送任何升级提示
# ─────────────────────────────────────
# 玩家升级时的提示方式
# mode 可选值:
#   chat      - 聊天栏显示文字消息
#   actionbar - 状态栏（物品栏上方）显示
#   title     - 屏幕中央大标题 + 副标题
level-up:
  # 提示模式: chat / actionbar / title
  mode: title

  # 聊天栏消息（仅 mode = chat 时生效）
  # 可用占位符: {player}, {level}, {old_level}
  chat:
    message: "&b&l✦ {player} &f升级了！ &7({old_level} → &b{level}&7)"

  # ActionBar 消息（仅 mode = actionbar 时生效）
  # 可用占位符: {player}, {level}, {old_level}
  actionbar:
    message: "&b&l✦ 升级！ &7你现在是 &bLv.{level}"

  # 标题消息（仅 mode = title 时生效）
  # 可用占位符: {player}, {level}, {old_level}
  title:
    # 大标题，设为空字符串则不显示大标题
    main: "&b&l✦ 升级！"
    # 副标题，设为空字符串则不显示副标题
    sub: "&7Lv.{level}"
    # 淡入时间（单位：刻，20刻 = 1秒）
    fade-in: 10
    # 停留时间（单位：刻）
    stay: 40
    # 淡出时间（单位：刻）
    fade-out: 10

  # 升级时播放的声音（留空表示不播放）
  sound: "ENTITY_PLAYER_LEVELUP"
  sound-volume: 0.5
  sound-pitch: 1.0

# ─────────────────────────────────────
# MySQL 数据库配置
# ─────────────────────────────────────
database:
  # 数据库地址
  host: localhost
  # 数据库端口
  port: 3306
  # 数据库名
  database: itemcore
  # 表名前缀
  table-prefix: ic_level_
  # 数据库用户名
  username: root
  # 数据库密码
  password: ""
  # 连接池设置
  pool-settings:
    # 最大连接数
    maximum-pool-size: 10
    # 最小空闲连接数
    minimum-idle: 2
    # 连接超时时间（毫秒）
    connection-timeout: 5000

# ─────────────────────────────────────
# PlaceholderAPI 进度条样式
# ─────────────────────────────────────
placeholder:
  progress-bar:
    # 进度条总长度（字符数）
    length: 20
    # 已完成的字符
    done-char: "█"
    # 已完成部分的颜色
    done-color: "&a"
    # 未完成的字符
    not-done-char: "░"
    # 未完成部分的颜色
    not-done-color: "&7"
```
